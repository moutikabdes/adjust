#################################################
#
#              fonctions d'approx
#
#     Discrète : getfitdistr
#
#     ~ : getgoodfit
#
#
#
#333333333333333333333333333333333333333333333333

#' Ajustement avec des distributions continues
#'
#' calcule la distribution la mieux ajustée pour les données fournies
#'
#' @param x la variable aléatoire continue a traitè
#' @param showplots valeur booléenne détermine s'il faut générer des courbes
#' @param short définit le format de valeur renvoyé
#' @param color définit les couleurs des courbes
#'
#' @return liste contenant la meilleure distribution ajustée lorsque  \code{short == TRUE}
#'         ou contenant toutes les distributions ajustées autrement
#'
#' @usage
#'  pour \strong{ short=TRUE}
#'    \code{fit <- getfitdistr(x)}
#'    pour accéder :\describe{
#'      \item{      au nom de la distribution la mieux ajustée}{    utilisez \strong{fit$loi}}
#'      \item{      au(x) paramétre(s) estimé(s) de cette distribution}{    utilisez \strong{fit$estimate}}
#'      \item{      ā l'AIC}{    utilisez \strong{fit$aic}}
#'      \item{      à la p-value}{    utilisez \strong{fit$p.value}}
#'    }
#'  pour \strong{short=FALSE}
#'    \code{fit <- getfitdistr(x, short=FALSE)}
#'    pour afficher les lois utilisées par cette fonction
#'      \code{> st$lois}
#'      \code{[1] "gamma"       "lognormal"   "exponential"}
#'
#'    pour accéder :\describe{
#'      \item{      au nom de distribution la mieux ajustée}{    utilisez \strong{fit$bestdistr}}
#'      \item{      aux distributions ayant une \emph{p-value>.05}}{    utilisez \strong{fit$acceptedDistr}}
#'      \item{      à la distribution ajustée de chaque \code{loi}}{   utilisez \strong{fit$loi}}
#'    }
#'la valeur \strong{fit$loi$accepthyp} détermine s'il faut rejeter l'hypothèse nulle pour la distribution de \strong{loi}
#'les colonnes sont presque les mêmes pour \code{getfitdistr(x)} et \code{getfitdistr(x, short=FALSE)$loi}
#' @author abdessabour moutik
#' @export

getfitdistr <- function(x, showplots=TRUE, short=TRUE, color=list(gamma = "blue", lognormal="red",exponential= "green"), detailed.curves=FALSE){
  library(MASS)
  aic <- function(l,p) -1*l + 2*p

  result <- list(lois=c("gamma", "lognormal", "exponential"))
  if(!showplots) detailed.curves = FALSE

  result$acceptedDistr <-data.frame(loi=character(0), aic=numeric(0), stringsAsFactors = FALSE)

  if(showplots) plot(ecdf(x), main=if(detailed.curves) "Fonction de répartition de x" else p("Fn de r. de x et des lois ", p(result$lois, sep =", ")))

  for (loi in result$lois) {

    fit <- fitdistr(x, loi)
    result[[loi]]$estimate <- fit$estimate
    sloi <- p("p", if(loi=="exponential") "exp" else if(loi=="lognormal") "lnorm" else loi )

    if(detailed.curves) {plot(ecdf(x), main = p("Ajustement de la fn de r de x par celle de la loi ", loi));legend(x=11.5,y=0.35, legend=c("fn de r. de x", p("fn de r. de la loi ", loi) ), lty=1:2, col = c("black", color[[loi]]))}

    if(showplots) curve(do.call(sloi, c( list(x) , as.vector(result[[loi]]$estimate))), add= TRUE, lwd=2, col=color[[loi]])

    ksstat <- do.call(ks.test, c(list(x, sloi), as.vector(result[[loi]]$estimate)))

    result[[loi]]$p.value <- ksstat$p.value
    result[[loi]]$accepthyp <- ksstat$p.value > .05

    result[[loi]]$aic <- aic(fit$loglik, if(loi=="exponential") 1 else 2)

    if(result[[loi]]$accepthyp){
      result$acceptedDistr[1,] <- c(loi, result[[loi]]$aic)
    }
  }

  if(showplots && !detailed.curves) legend(x=11.5,y=0.35, legend=c("fn de r. de x", "fn de r. de la loi gamma", "fn de r. de la loi lognormal", "fn de r. de la loi exponentiel"), lty=1:4, col = c("black", as.character(color)))

  if (length(result$acceptedDistr$loi)==0) {print("All the distributions failed to confirm the null hypothesis");return(result)}

  result$bestdistr <- with(result$acceptedDistr, loi[aic==min(aic)])
  if(short) {
    loi=result$bestdistr;
    c(list(loi=loi), result[[loi]][names(result[[loi]]) != "accepthyp"])
  }  else result
}


#' Ajustement avec des distributions discrètes
#'
#' calcule la distribution la mieux ajustée pour les données fournies
#'
#' @param x la variable aléatoire discrètes a traitè
#' @param showplots valeur booléenne détermine s'il faut générer des courbes
#' @param short définit le format de la valeur renvoyée par défaut TRUE
#'
#' @return liste contenant la meilleure distribution ajustée lorsque  \code{short == TRUE}
#'         ou contenant toutes les distributions ajustées autrement avec la meillieure distribution,
#'         si elle existe, dans \code{result$bestdistr} et ceux dont l'hypothèse nulle est acceptée se
#'         trouve dans \code{result$acceptedDistr}
#'
#' @usage
#'  pour \strong{ short=TRUE}
#'    \code{fit <- getfitdistr(x)}
#'    pour accéder :\describe{
#'      \item{      au nom de la distribution la mieux ajustée}{    utilisez \strong{fit$loi}}
#'      \item{      au(x) paramétre(s) estimé(s) de cette distribution}{    utilisez \strong{fit$estimate}}
#'      \item{      aux effectifs observé (resp. théorique)}{    utilisez \strong{fit$observed (resp. fit$fitted)}}
#'      \item{      à la distribution de probabilité}{    utilisez \strong{fit$prob}}
#'      \item{      au degré de liberté}{    utilisez \strong{fit$df}}
#'      \item{      aux états de la V.A x}{    utilisez \strong{fit$count}}
#'      \item{      ā la statistique khi-2}{    utilisez \strong{fit$Xsquared}}
#'      \item{      à la p-value}{    utilisez \strong{fit$p.value}}
#'    }
#'
#'  pour \strong{short=FALSE}
#'    \code{fit <- getfitdistr(x, short=FALSE)}
#'    pour afficher les lois utilisées par cette fonction
#'      \code{> fit$lois}
#'      \code{[1] "pois"   "binom"  "nbinom"}
#'    pour accéder :\describe{
#'      \item{      au nom de distribution la mieux ajustée}{    utilisez \strong{fit$bestdistr}}
#'      \item{      aux distributions ayant une \emph{p-value>.05}}{    utilisez \strong{fit$acceptedDistr}}
#'      \item{      à la distribution ajustée de chaque \code{loi}}{   utilisez \strong{fit$loi}}
#'    }
#'la valeur \strong{fit$loi$accepthyp} détermine s'il faut rejeter l'hypothèse nulle pour la distribution de \strong{loi}
#'les colonnes sont presque les mêmes pour \code{getfitdistr(x)} et \code{getfitdistr(x, short=FALSE)$loi}
#' @author abdessabour moutik
#' @export
getgoodfit <- function(x, showplots=TRUE, short=TRUE){

  library(vcd)
  sumlast <- function(y,l=length(y)) c(y[1:(l-2)], sum(y[(l-1):l]))

  result <- list(lois=c("pois", "binom", "nbinom"))
  default.length <- length(table(x))-1
  moy = mean(x)
  v = var(x)

  result$acceptedDistr <-data.frame(loi=character(0), stat=numeric(0), stringsAsFactors = FALSE)

  if(showplots) barplot(table(x))
  for (loi in result$lois) {
    if(loi!="pois"){
      par <- list( size = getsize(moy, v, loi) )
      if(par$size<0 || is.na(par$size)) {print(p("Erreur lors de l'estimation du parametre n = ", par$size, " de la loi ", if(loi=="nbinom") "binomiale négative" else "binomiale")); par$size <- default.length}
      fit <- goodfit(x, loi, par = par)
    } else {
      fit <- goodfit(x, loi)
    }
    if(showplots) sloi <- p("Ajustement avec une distrubition ", if(loi=="pois") "de poisson" else if(loi=="nbinom") "binomiale négative" else "binomiale");plot(fit, main=sloi)

    result[[loi]]$fitted <- fit$fitted
    result[[loi]]$observed <- fit$observed

    l = length(result[[loi]]$observed)

    while(sum(result[[loi]]$fitted<=5)>l/10){
      result[[loi]]$fitted <- sumlast(result[[loi]]$fitted, l)
      result[[loi]]$observed <- sumlast(result[[loi]]$observed, l)
      l <- l-1
    }

    result[[loi]]$estimate <- fit$par
    #distrfunc <- get(p("d", loi))

    distr <- do.call(p("d", loi), c(list(x=0:(l-2)),list(lambda=result[[loi]]$estimate$lambda)[loi=="pois"], list(size=result[[loi]]$estimate$size, prob=result[[loi]]$estimate$prob)[loi!="pois"]))
    result[[loi]]$prob <- c(distr, 1-sum(distr))

    result[[loi]]$df <- l-(if(loi=="pois") 2 else 3)
    result[[loi]]$df <- if(result[[loi]]$df==0) 1 else result[[loi]]$df
    chisqstat <- chisq.test(result[[loi]]$observed, p=result[[loi]]$prob)

    result[[loi]]$Xsquared <- as.numeric(chisqstat$statistic)
    result[[loi]]$p.value <- as.numeric(1-pchisq(result[[loi]]$Xsquared, result[[loi]]$df))

    result[[loi]]$accepthyp <- result[[loi]]$p.value > .05 || result[[loi]]$Xsquared < qchisq(0.95,result[[loi]]$df)

    result[[loi]]$count <-0:(l-1)

    if(result[[loi]]$accepthyp){
      result$acceptedDistr[1,] <- c(loi, result[[loi]]$Xsquared)
    }
  }

  if (length(result$acceptedDistr$loi)==0) {print("All the distributions failed to confirm the null hypothesis");return(result)}

  result$bestdistr <- with(result$acceptedDistr, loi[stat==min(stat)])


  if(short) {
    loi=result$bestdistr; c(list(loi=loi), result[[loi]][names(result[[loi]])!= "accepthyp"])
  }  else result
}

# esmtimate= result[[loi]]$estimate, Xsquared=result[[loi]]$Xsquared, observed=result[[loi]]$observed, count=result[[loi]]$count,df=result[[loi]]$df,fitted=result[[loi]]$fitted, p.value=result[[loi]]$p.value)

getsize <- function(moyenne, variance, loi) {
  v = as.numeric(variance)
  m = as.numeric(moyenne)
  n <- NA
  if(loi=="nbinom" && m<v){
    n <- (log((m/v)*m)) / log(1-(m/v))
  }else if(loi=="binom" && m!=v){
    n <- round(m/(1-(v/m)))
  }
  n
}

p <- function(..., sep='') {
  paste(..., sep=sep, collapse=sep)
}
